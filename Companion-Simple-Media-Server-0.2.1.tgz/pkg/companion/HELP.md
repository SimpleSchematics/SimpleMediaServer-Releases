# Simple Media Server — Companion 0.2.0

This development module controls the Mac incoming TCP JSON receiver. Windows compatibility requires the same protocol and advertised actions; a Windows live test is still required.

## Setup

1. In Simple Media Server, open Settings → Show Control → Incoming.
2. Generate a control token. Start incoming controls. TCP defaults to 38751.
3. For Companion on this Mac, use 127.0.0.1 and leave Allow LAN off. For another computer, select the intended LAN adapter and allow the app through the appropriate firewall locally.
4. Install the supplied module package using Companion's custom-module installation workflow. Add the Simple Media Server connection; enter host, TCP port and matching token.
5. Refresh status. Select actions and targets from the project catalogue. Use Main for global/group/device actions; Auto selects the owning timeline for a listed cue, section or clip.

Save incoming settings explicitly if you want the Mac to remember the token. The receiver remains OFF after relaunch. Tokens are stored in a private local settings file; Companion configuration exports also contain the token. Do not publish them.

## Behavior

The module polls transport status once per second and reloads the catalogue only when its revision changes. It serializes requests, bounds the queue at 16, applies a three-second response deadline and never automatically retries a mutation. A connection error may occur after a command reached the server; verify status before repeating it.

Time accepts non-negative seconds or HH:MM:SS:FF at the server's reported FPS. Target UUIDs avoid ambiguity when names repeat. Clip means go to the clip's start, not solo it. Pause leaves Free Play clips running; Stop stops the addressed timeline's playback. Fades affect master video only. A successful reply confirms command acceptance, not completed playback or external device execution. Send show commands to the active Leader; Nodes accept status only.

## Actions

| ID | Arguments | Meaning |
|---|---|---|
| `status` | none | TCP reply includes transport, FPS, duration, cues, sections, clips, timeline groups, independent timeline IDs and device actions. OSC has no reply. |
| `play` | none | Resume the addressed timeline. Playback requires activation. |
| `pause` | none | Pause timeline transport. Free Play clips keep their independent clocks. |
| `stop` | none | Stop the addressed timeline and its clip playback. |
| `seek` | number: seconds | Seek within the addressed timeline, without implicitly starting it. |
| `clip` | string: clip UUID | Start at this clip's timeline position. Other overlapping layers are not soloed. |
| `cue` | string: cue UUID or exact name | Run the cue's configured behavior, including the show's transition settings. Prefer UUIDs when names repeat. |
| `section` | string: section UUID or exact name | Start at the section's beginning using its timeline's transition behavior. |
| `fadeIn` | optional number: seconds (default 1) | Fade master video level to one over more than zero and at most 120 seconds. Audio is unchanged. |
| `fadeOut` | optional number: seconds (default 1) | Fade master video level to zero over more than zero and at most 120 seconds. Audio is unchanged. |
| `playAll` | none; Main scope only | Resume Main and all independent timelines. Does not change which timeline is selected in the editor. |
| `pauseAll` | none; Main scope only | Pause transport on Main and all independent timelines; Free Play remains independent. |
| `stopAll` | none; Main scope only | Stop Main and all independent timelines. |
| `groupPlay` | string: group UUID or exact name | Start the configured timeline group. |
| `groupPause` | string: group UUID or exact name | Pause the configured timeline group. |
| `groupStop` | string: group UUID or exact name | Stop the configured timeline group. |
| `device` | string: configured action UUID or exact name | Send an outgoing device command already configured in the app. Acceptance is not proof the external device changed state. |
| `deviceBatch` | none | Send the configured outgoing takeover command list. This does not transfer the Leader role. |

## Feedback and variables

Connected, playing, preparing, device busy and blackout feedback are available. Variables include server FPS, seconds/timecode, level, role, project, connection and device-command state. The module supplies nine basic transport presets. Inspect live status after project changes before using cached targets.

## Troubleshooting

Connection failure: check receiver enabled, host, port, adapter and firewall. Authentication failure: match the current token. Unknown target: refresh catalogue and verify timeline scope. Playback rejection: check activation and active Leader. A green TCP status is not proof of media readiness, smooth playback, physical sync or NDI quality.

## Development verification

Use Node 22.18 or later in the Node 22 series. Run `npm ci --ignore-scripts`, `npm test`, then `npm run package`. Unit/socket tests do not replace a real Companion UI and live playback test. Read BUILD-REPORT.txt for the exact tested status.
